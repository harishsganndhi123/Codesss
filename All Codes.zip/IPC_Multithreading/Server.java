
import java.util.*;
import java.io.*;
import java.net.*;

public class Server  {
    public static void main(String[] args) {
        // System.out.println("Jay Shree Ganesha!");
		ServerSocket ss;
		try
		{

			ss = new ServerSocket(45023);
			ss.setReuseAddress(true);
			while(true) 
			{
				
				System.out.println("Waiting for clients...");
				Socket soc = ss.accept();
				
				System.out.println("Connection established with "+soc.getInetAddress()+":"+soc.getPort());
		        ClientHandler ch = new ClientHandler(soc);
		        new Thread(ch).start();
				System.out.println();
			}
			
		}
		catch(Exception e) 
		{
			System.out.println("Exception in Server Class.");
			e.printStackTrace();
			return;
		}

    }
}


class ClientHandler implements Runnable
{
	Socket soc;
	static int count = 0;
	ClientHandler(Socket s) {
		soc=s;
		count++;
	}
	public void start() {
		System.out.println("Client no. "+count+" connected!");		
	}
	public void run() {
		BufferedReader in;
		PrintWriter out;
		try
		{
			in = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			out = new PrintWriter(soc.getOutputStream(), true);			
		}
		catch(Exception e)
		{
			System.out.println("Error in creating streams!");
			e.printStackTrace();
			return;
		}
		while(true) 
		{
			
			try
			{
				
				String str="";
				System.out.println("Listening...");
				str=in.readLine();
				System.out.println("Got "+str+" from client.");
				out.println(str);
				System.out.println("Sent back to Client.");
				
			}
			catch(Exception e) 
			{
				System.out.println("Error in reading or writing.");
				e.printStackTrace();
			}
			
		}

		
	}
}