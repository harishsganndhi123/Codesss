
import java.util.*;
import java.io.*;
import java.net.*;
public class Client {
	public static void main(String args[]) throws Exception{
		
		Socket soc=new Socket("localhost", 45023);
		
		// create in and out for socket
		Scanner in = new Scanner((soc.getInputStream()));
		PrintWriter out = new PrintWriter(soc.getOutputStream(), true);
		Scanner scan=new Scanner(System.in);
		String str="";
		String echo_str="";
		while(true) 
		{
			System.out.print("Enter a string: ");
			str=scan.next();
			out.println(str);				
			echo_str=in.next();
			
			System.out.println("Echo: "+echo_str);
		
		}
		
	}
}
